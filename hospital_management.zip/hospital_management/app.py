from flask import Flask, render_template, request, redirect, url_for
import mysql.connector

app = Flask(__name__)

# MySQL Connection
conn = mysql.connector.connect(
    host='localhost',
    user='root',        # Apna MySQL user name
    password='programmer@123',  # Apna MySQL password
    database='hospital_db2'
)

cursor = conn.cursor(dictionary=True)

@app.route('/')
def home():
    return render_template('home.html')

# Patients CRUD
@app.route('/patients')
def patients():
    cursor.execute("SELECT * FROM patients")
    patients = cursor.fetchall()
    return render_template('patients.html', patients=patients)

@app.route('/add_patient', methods=['GET', 'POST'])
def add_patient():
    if request.method == 'POST':
        name = request.form['name']
        age = request.form['age']
        gender = request.form['gender']
        address = request.form['address']
        phone = request.form['phone']
        cursor.execute("INSERT INTO patients (name, age, gender, address, phone) VALUES (%s,%s,%s,%s,%s)",
                       (name, age, gender, address, phone))
        conn.commit()
        return redirect(url_for('patients'))
    return render_template('add_patient.html')

# Doctors CRUD
@app.route('/doctors')
def doctors():
    cursor.execute("SELECT * FROM doctors")
    doctors = cursor.fetchall()
    return render_template('doctors.html', doctors=doctors)

@app.route('/add_doctor', methods=['GET', 'POST'])
def add_doctor():
    if request.method == 'POST':
        name = request.form['name']
        specialty = request.form['specialty']
        phone = request.form['phone']
        cursor.execute("INSERT INTO doctors (name, specialty, phone) VALUES (%s,%s,%s)", (name, specialty, phone))
        conn.commit()
        return redirect(url_for('doctors'))
    return render_template('add_doctor.html')

# Appointments CRUD
@app.route('/appointments')
def appointments():
    query = """
    SELECT appointments.id, patients.name as patient_name, doctors.name as doctor_name, 
           appointment_date, appointment_time
    FROM appointments
    JOIN patients ON appointments.patient_id = patients.id
    JOIN doctors ON appointments.doctor_id = doctors.id
    """
    cursor.execute(query)
    appointments = cursor.fetchall()
    return render_template('appointments.html', appointments=appointments)

# app.py me
@app.route('/add_appointment', methods=['GET', 'POST'])
def add_appointment():
    if request.method == 'POST':
        patient_id = request.form['patient_id']
        doctor_id = request.form['doctor_id']
        appointment_date = request.form['appointment_date']
        appointment_time = request.form['appointment_time']
        # Yahan status ka koi field nahi hai, agar hai toh use bhi le lein
        cursor.execute(
            "INSERT INTO appointments (patient_id, doctor_id, appointment_date, appointment_time) VALUES (%s, %s, %s, %s)",
            (patient_id, doctor_id, appointment_date, appointment_time)
        )
        conn.commit()
        return redirect(url_for('appointments'))
    cursor.execute("SELECT * FROM patients")
    patients = cursor.fetchall()
    cursor.execute("SELECT * FROM doctors")
    doctors = cursor.fetchall()
    return render_template('add_appointment.html', patients=patients, doctors=doctors)


if __name__ == '__main__':
    app.run(debug=True)
